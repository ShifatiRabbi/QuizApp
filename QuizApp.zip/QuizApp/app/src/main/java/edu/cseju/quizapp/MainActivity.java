package edu.cseju.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private TextView mTvScore, mTvQuestion;
    private Button mBtnSubmit;
    private RadioButton mRdOption1, mRdOption2, mRdOption3;
    private EditText mEdtScore;

    private int i = 0;
    private int score = 0;
    private Model model = new Model();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mTvQuestion = findViewById(R.id.mTvQuestion);
        mBtnSubmit = findViewById(R.id.mBtnSubmit);
        mEdtScore = findViewById(R.id.mEdtScore);
        mRdOption1 = findViewById(R.id.mRdOption1);
        mRdOption2 = findViewById(R.id.mRdOption2);
        mRdOption3 = findViewById(R.id.mRdOption3);

        mBtnSubmit.setOnClickListener(this);
        mRdOption1.setOnClickListener(this);
        mRdOption2.setOnClickListener(this);
        mRdOption3.setOnClickListener(this);

        updateQuestion();

        //System.out.println(model.getQuestionset(1));

    }

    @Override
    public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.mBtnSubmit:
                i++;
                updateQuestion();
                break;

            case R.id.mRdOption1:
                checkAnswer(mRdOption1);
                break;
            case R.id.mRdOption2:
                checkAnswer(mRdOption2);
                break;

            case R.id.mRdOption3:
                checkAnswer(mRdOption3);
                break;

        }
    }


    public void updateQuestion()
    {
        mRdOption1.setChecked(false);
        mRdOption2.setChecked(false);
        mRdOption3.setChecked(false);

        try {

            mTvQuestion.setText(model.getQuestionset(i));
            mRdOption1.setText(model.getOptions1(i));
            mRdOption2.setText(model.getOptions2(i));
            mRdOption3.setText(model.getOptions3(i));
        }
        catch (Exception e)
        {
            Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
        }

    }

    public void checkAnswer(RadioButton radioButton)
    {
        String text = String.valueOf(radioButton.getText());
        System.out.println(text);
        System.out.println(model.getAnswers(i));
        if (model.getAnswers(i).matches(text))
        {
            score = score +1;
            mEdtScore.setText("" + score);
        }
    }
}