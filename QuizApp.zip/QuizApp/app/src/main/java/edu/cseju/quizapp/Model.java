package edu.cseju.quizapp;

public class Model {

    public Model() {

    }

    private String [] questionset =
            {
                    "Who was elected President of the United States in 2017?",
                    "When did Jonas Brothers make their comeback to the music world?",
                    "What is the national language of Canada?",
                    " What is the national animal of Pakistan?",
                    " A la Crecy is a French dish made of what?",
                    " What native country is Brazil?",
                    "Brazil is the biggest producer of?"

            };

    private String [][] options =
            {
                    {"Donald Trump", "Barack Obama", "George Bush"},
                    {"2015", "2011", "2019"},
                    {"English", "Dutch", "French"},
                    {"Peacock", "Markhor", "Loin"},
                    {"Apples", "Carrots", "Potatoes"},
                    {"South American", "North American", "West American"},
                    {"Rice", "Oil", "Coffee"}

            };

    private String [] answers =
            {
                    "Donald Trump",
                    "2019",
                    "Dutch",
                    "Markhor",
                    "Carrots",
                    "North American",
                    "Coffee"
            };

    public String getQuestionset(int i) {
        return questionset[i];
    }

    public String getOptions1(int i) {
        return options[i][0];
    }

    public String getOptions2(int i) {
        return options[i][1];
    }

    public String getOptions3(int i) {
        return options[i][2];
    }

    public String getAnswers(int i) {
        return answers[i];
    }
}
